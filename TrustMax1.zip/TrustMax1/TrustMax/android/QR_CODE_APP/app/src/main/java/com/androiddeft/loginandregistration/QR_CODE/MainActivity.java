package com.androiddeft.loginandregistration.QR_CODE;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import com.androiddeft.loginandregistration.Home;
import com.androiddeft.loginandregistration.LoginActivity;
import com.androiddeft.loginandregistration.QrUploadToServer;
import com.androiddeft.loginandregistration.R;
import com.androiddeft.loginandregistration.SessionHandler;
import com.androiddeft.loginandregistration.User;

public class MainActivity extends AppCompatActivity {
    private SessionHandler session;

    private  static  String TAG ="errorMsg";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        session = new SessionHandler(getApplicationContext());
        User user = session.getUserDetails();

        Button logoutBtn = findViewById(R.id.btnLogout);

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                session.logoutUser();
                Intent i = new Intent(MainActivity.this, Home.class);
                startActivity(i);
                finish();

            }
        });
    }

    public void readQr(View view){
        Intent intent=new Intent(MainActivity.this,QrRead.class);
        startActivity(intent);
    }
    public void generateQr(View view){
        Intent intent=new Intent(MainActivity.this,QrGenerator.class);
        startActivity(intent);
    }
    public void uploadQR(View view) {
        Intent intent=new Intent(MainActivity.this,QrUploadToServer.class);
        startActivity(intent);
        Log.i(TAG,"was the error");
    }
}
