package com.androiddeft.loginandregistration;

public class Constants {

    public static final String UPLOAD_URL = "http://10.0.2.2:80/AndroidImageUpload/upload.php";
    //public static final String IMAGES_URL = "http://192.168.43.56:80/AndroidImageUpload/getImages.php";
    public static final String IMAGES_URL = "http://10.0.2.2:80/AndroidImageUpload/getImages.php";
    //public static final String IMAGES_URL = "http://10.0.2.2:80/AndroidImageUpload/getImages.php";

   /// public static final String IMAGES_URL = "http://192.168.137.90:80/AndroidImageUpload/getImages.php";
}
