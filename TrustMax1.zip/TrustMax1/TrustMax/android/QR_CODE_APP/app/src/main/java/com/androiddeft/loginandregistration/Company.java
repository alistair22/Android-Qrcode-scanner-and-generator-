package com.androiddeft.loginandregistration;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.androiddeft.loginandregistration.QR_CODE.MainActivity;
import com.androiddeft.loginandregistration.QR_CODE.QrRead;

public class Company extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company);
    }

    public void AdminQr(View view) {
        Intent intent=new Intent(Company.this,QrRead.class);
        startActivity(intent);
    }
}
